<?php

namespace App\Notifications;

use App\Models\Account;
use Illuminate\Notifications\Notification;

/**
 * PART 4: created with php artisan make:notification LowBalanceNotification
 */
class LowBalanceNotification extends Notification
{
    public function __construct(public Account $account)
    {
    }

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function toArray(object $notifiable): array
    {
        return [
            'account_number' => $this->account->account_number,
            'balance' => $this->account->balance,
            'minimum_balance' => $this->account->minimum_balance,
            'message' => "Low balance alert: account {$this->account->account_number} is at "
                . number_format($this->account->balance, 2)
                . " (minimum is " . number_format($this->account->minimum_balance, 2) . ").",
        ];
    }
}
