<?php

namespace App\Observers;

use App\Exceptions\InsufficientFundsException;
use App\Models\Account;
use App\Models\Transaction;
use App\Notifications\LowBalanceNotification;
use Illuminate\Support\Facades\DB;

/**
 * PART 2: balance update + banking rules (creating)
 * PART 4: low balance notification after a withdrawal (created)
 */
class AccountObserver
{
    /**
     * Runs BEFORE the transaction row is saved.
     * Updates the account balance, or throws to stop the save.
     */
    public function creating(Transaction $transaction): void
    {
        DB::transaction(function () use ($transaction) {
            // lock the row so two requests can't change the balance at the same time
            $account = Account::lockForUpdate()->findOrFail($transaction->account_id);

            $balance = (float) $account->balance;
            $amount  = (float) $transaction->amount;

            if ($transaction->type === 'deposit') {
                $newBalance = $balance + $amount;
            } else { // withdrawal or transfer
                $newBalance = $balance - $amount;

                if ($newBalance < 0 || $newBalance < (float) $account->minimum_balance) {
                    throw new InsufficientFundsException(
                        'Insufficient funds: the balance cannot go below the minimum balance of '
                        . number_format($account->minimum_balance, 2) . '.'
                    );
                }
            }

            $account->balance = round($newBalance, 2);

            // balance is healthy again -> allow future low-balance alerts
            if ($account->balance > $account->minimum_balance) {
                $account->low_balance_notified = false;
            }

            $account->save();
        });
    }

    /**
     * Runs AFTER the transaction row is saved.
     * Sends the low balance alert after a withdrawal (only once).
     */
    public function created(Transaction $transaction): void
    {
        if ($transaction->type === 'deposit') {
            return;
        }

        $account = Account::find($transaction->account_id);

        if ($account->balance <= $account->minimum_balance && ! $account->low_balance_notified) {
            $account->user->notify(new LowBalanceNotification($account));
            $account->update(['low_balance_notified' => true]);
        }
    }
}
