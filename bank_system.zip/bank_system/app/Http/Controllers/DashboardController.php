<?php

namespace App\Http\Controllers;

use App\Models\Account;
use App\Models\Transaction;

/**
 * PART 4: GET /api/dashboard/stats returns JSON for the AJAX polling.
 */
class DashboardController extends Controller
{
    // Page
    public function index()
    {
        return view('dashboard');
    }

    // JSON endpoint: GET /api/dashboard/stats
    public function stats()
    {
        return response()->json([
            'total_accounts'     => Account::count(),
            'total_money'        => (float) Account::sum('balance'),
            'transactions_today' => Transaction::whereDate('created_at', today())->count(),
        ]);
    }
}
