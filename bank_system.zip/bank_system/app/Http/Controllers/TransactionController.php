<?php

namespace App\Http\Controllers;

use App\Exceptions\InsufficientFundsException;
use App\Models\Account;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

/**
 * PART 3: index(), create(), store() with validation.
 * store() wraps the save in DB::transaction() (PART 2).
 */
class TransactionController extends Controller
{
    public function index(Request $request)
    {
        $accountIds = $request->user()->accounts()->pluck('id');

        $transactions = Transaction::with('account')
            ->whereIn('account_id', $accountIds)
            ->latest()
            ->paginate(10);

        return view('transactions.index', compact('transactions'));
    }

    public function create(Request $request)
    {
        $accounts = $request->user()->accounts;

        return view('transactions.create', compact('accounts'));
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'account_id' => ['required', Rule::exists('accounts', 'id')->where('user_id', $request->user()->id)],
            'type'       => ['required', Rule::in(['deposit', 'withdrawal'])],
            'amount'     => ['required', 'numeric', 'min:1'],
            'notes'      => ['nullable', 'string', 'max:255'],
        ]);

        // Custom validation: enough funds for a withdrawal?
        $validator->after(function ($validator) use ($request) {
            if ($validator->errors()->isNotEmpty() || $request->type !== 'withdrawal') {
                return;
            }

            $account = Account::find($request->account_id);

            if (($account->balance - $request->amount) < $account->minimum_balance) {
                $validator->errors()->add(
                    'amount',
                    'Insufficient funds. Available to withdraw: '
                    . number_format(max(0, $account->balance - $account->minimum_balance), 2)
                );
            }
        });

        $data = $validator->validate();

        try {
            DB::transaction(function () use ($data) {
                // The AccountObserver updates the balance when this row is created.
                // If it throws, the whole DB transaction is rolled back.
                Transaction::create([
                    'account_id'       => $data['account_id'],
                    'type'             => $data['type'],
                    'amount'           => $data['amount'],
                    'reference_number' => strtoupper(Str::random(10)),
                    'notes'            => $data['notes'] ?? null,
                ]);
            });
        } catch (InsufficientFundsException $e) {
            return back()->withErrors(['amount' => $e->getMessage()])->withInput();
        }

        return redirect()->route('transactions.index')->with('success', 'Transaction completed.');
    }
}
