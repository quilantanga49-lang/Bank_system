@extends('layouts.bank')

@section('content')
<h3 class="mb-3">New Transaction</h3>

<div class="card shadow-sm"><div class="card-body">
    <form method="POST" action="{{ route('transactions.store') }}">
        @csrf

        <div class="mb-3">
            <label class="form-label">Account</label>
            <select name="account_id" class="form-select @error('account_id') is-invalid @enderror">
                @foreach ($accounts as $account)
                    <option value="{{ $account->id }}" @selected(old('account_id') == $account->id)>
                        {{ $account->account_number }} (Balance: {{ number_format($account->balance, 2) }})
                    </option>
                @endforeach
            </select>
            @error('account_id') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Type</label>
            <select name="type" class="form-select @error('type') is-invalid @enderror">
                <option value="deposit" @selected(old('type') == 'deposit')>Deposit</option>
                <option value="withdrawal" @selected(old('type') == 'withdrawal')>Withdrawal</option>
            </select>
            @error('type') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Amount</label>
            <input type="number" step="0.01" name="amount" value="{{ old('amount') }}"
                   class="form-control @error('amount') is-invalid @enderror">
            @error('amount') <div class="invalid-feedback">{{ $message }}</div> @enderror
        </div>

        <div class="mb-3">
            <label class="form-label">Notes (optional)</label>
            <textarea name="notes" class="form-control">{{ old('notes') }}</textarea>
        </div>

        <button class="btn btn-primary">Submit</button>
    </form>
</div></div>
@endsection
