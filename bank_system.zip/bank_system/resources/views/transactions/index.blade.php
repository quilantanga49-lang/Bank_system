@extends('layouts.bank')

@section('content')
<div class="d-flex justify-content-between mb-3">
    <h3>Transaction History</h3>
    <a href="{{ route('transactions.create') }}" class="btn btn-primary">New Transaction</a>
</div>

<div class="card shadow-sm"><div class="card-body p-0">
    <table class="table table-striped mb-0">
        <thead>
            <tr>
                <th>Date</th><th>Account</th><th>Type</th><th>Amount</th><th>Reference</th><th>Notes</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($transactions as $t)
                <tr>
                    <td>{{ $t->created_at->format('Y-m-d H:i') }}</td>
                    <td>{{ $t->account->account_number }}</td>
                    <td><span class="badge bg-{{ $t->type === 'deposit' ? 'success' : 'danger' }}">{{ ucfirst($t->type) }}</span></td>
                    <td>{{ number_format($t->amount, 2) }}</td>
                    <td>{{ $t->reference_number }}</td>
                    <td>{{ $t->notes }}</td>
                </tr>
            @empty
                <tr><td colspan="6" class="text-center text-muted">No transactions yet.</td></tr>
            @endforelse
        </tbody>
    </table>
</div></div>

<div class="mt-3">{{ $transactions->links() }}</div>
@endsection
