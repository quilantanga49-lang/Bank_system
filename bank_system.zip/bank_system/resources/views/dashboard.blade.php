@extends('layouts.bank')

@section('content')
<h3 class="mb-3">Bank Dashboard <small class="text-muted fs-6">(updates every 30 seconds)</small></h3>

<div class="row text-center">
    <div class="col-md-4 mb-3">
        <div class="card shadow-sm"><div class="card-body">
            <div class="text-muted">Total Accounts</div>
            <h2 id="total-accounts">--</h2>
        </div></div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card shadow-sm"><div class="card-body">
            <div class="text-muted">Total Money in Bank</div>
            <h2 id="total-money">--</h2>
        </div></div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card shadow-sm"><div class="card-body">
            <div class="text-muted">Transactions Today</div>
            <h2 id="transactions-today">--</h2>
        </div></div>
    </div>
</div>
<p class="text-muted small">Last updated: <span id="last-updated">never</span></p>
@endsection

@push('scripts')
<script>
    // PART 4: fetch /api/dashboard/stats every 30 seconds and update the page
    // AJAX polling: fetch stats now, then every 30 seconds
    function loadStats() {
        fetch('/api/dashboard/stats', { headers: { 'Accept': 'application/json' } })
            .then(res => res.json())
            .then(data => {
                document.getElementById('total-accounts').textContent = data.total_accounts;
                document.getElementById('total-money').textContent =
                    '₱' + Number(data.total_money).toLocaleString(undefined, { minimumFractionDigits: 2 });
                document.getElementById('transactions-today').textContent = data.transactions_today;
                document.getElementById('last-updated').textContent = new Date().toLocaleTimeString();
            })
            .catch(err => console.error('Failed to load stats', err));
    }

    loadStats();
    setInterval(loadStats, 30000);
</script>
@endpush
